var myArray = [ 			// Tableau des différents produits
		'X0154', 'GeForce GTX Titan', '719.99',
		'X0883', 'GeForce GTX Phantom', '358.99',
		'R0052', 'Sapphire Radeon HD 7850', '125.35',
		'R9089', 'MSI Radeon R9 295 X2', '989.00'
];
var mySociety = [  			// Tableau des différentes sociétés
		'Netscape 2.0', 'Netscape AOL', '19 avenue de choisy', '75013, Paris','01 45 86 70 58',
		'You and I production', 'Dupont','6 rue Gassendi', '75014, Paris', '01 45 90 52 41',
		'Starcraft Unity', 'Artosis', '151 rue de Grenelle', '75007, Paris', '01 45 85 21 60',
		'Godus', 'Moulineau', '13 quai Voltaire', '75007, Paris', '01 45 20 47 90',
];
var myCustomer = [			// Tableau des différents clients
		'Cabinet Gerard', 'Gerard', '16 avenue Eugène Thomas', '94270, Le Kremlin-bicêtre', '01 45 70 50 40',
		'Putrovski corporation', 'Vladimir', '82 rue de Charenton', '75012, Paris', '01 45 80 70 70',
		'Chinchan family', 'Chinchan', '39 rue Petit', '75019, Paris', '01 45 03 03 04',
		'La main invisible', 'Smith', '106 rue Nollet', '75017, Paris', '01 45 66 04 02',
];

var nombre_rangees = 4; // On fixe le nombre de lignes du tableau de la facture à 4

function remplirSoc(i){

var societe = document.getElementById('societe');		// On récupère l'élément societe


// Une liste déroulante permettant de choisir le nouveau client dans les formulaires émetteur et destinataire
societe.options[0].text = 'Nouveau client';		// La valeur de base est nouveau client
societe.options[1].text = mySociety[0];
societe.options[2].text = mySociety[5];
societe.options[3].text = mySociety[10];
societe.options[4].text = mySociety[15];

var nomSo = document.getElementById('nomSo');
var nom = document.getElementById('nom');
var rue = document.getElementById('rue');
var ville = document.getElementById('ville');
var telephone = document.getElementById('telephone');

societe.addEventListener('change', function() {

	switch(societe.options.selectedIndex){				// Placer automatiquement les attributs du tableau mySociety en fonction de l'option choisie et de la case destinataire
		case 0 :
			nomSo.value = "";
			nomSo.placeholder = 'Nom de la societe';		// Placeholder donne une indication sur la nature de la case et la valeur attendue
			nomSo.disabled = false;						// Disabled permet de modifier la valeur du champ
			nom.value = "";					
			nom.placeholder = 'Nom';
			nom.disabled = false;					// Permet de modifier la valeur du champ également... 
			rue.value = "";
			rue.placeholder = 'Rue';
			rue.disabled = false;
			ville.value = "";
			ville.placeholder = 'Code postal, Ville';
			ville.disabled = false;
			telephone.value = "";
			telephone.placeholder = 'Numero de telephone';
			telephone.disabled = false;
			break;
			
		case 1 :
			nomSo.value = mySociety[0];								// La valeur de mySociety[0] est récupérée en tant que nom de la société
			nomSo.disabled = true;		// Cette fois-ci interdit de modifier la valeur
			nom.value = mySociety[1];								// La valeur de mySociety[1] est récupérée en tant que nom du client
			nom.disabled = true;			
			rue.value = mySociety[2];								// La valeur de mySociety[2] est récupérée en tant que nom de la rue
			rue.disabled = true;		
			ville.value = mySociety[3];								// La valeur de mySociety[3] est récupérée en tant que nom de la ville
			ville.disabled = true;
			telephone.value = mySociety[4];							// La valeur de mySociety[4] est récupérée en tant que numéro de téléphone
			telephone.disabled = true;
			break;
			
		case 2 :
			nomSo.value = mySociety[5];							// La valeur de mySociety[5] est récupérée en tant que nom de la société
			nomSo.disabled = true;
			nom.value = mySociety[6];
			nom.disabled = true;
			rue.value = mySociety[7];
			rue.disabled = true;
			ville.value = mySociety[8];
			ville.disabled = true;
			telephone.value = mySociety[9];
			telephone.disabled = true;
			break;
			
		case 3 :
			nomSo.value = mySociety[10];					// La valeur de mySociety[10] est récupérée en tant que nom de la société
			nomSo.disabled = true;
			nom.value = mySociety[11];
			nom.disabled = true;
			rue.value = mySociety[12];
			rue.disabled = true;
			ville.value = mySociety[13];
			ville.disabled = true;
			telephone.value = mySociety[14];
			telephone.disabled = true;
			break;
			
		case 4 :
			nomSo.value = mySociety[15];						// La valeur de mySociety[15] est récupérée en tant que nom de la société
			nomSo.disabled = true;
			nom.value = mySociety[16];
			nom.disabled = true;
			rue.value = mySociety[17];
			rue.disabled = true;
			ville.value = mySociety[18];
			ville.disabled = true;
			telephone.value = mySociety[19];
			telephone.disabled = true;
			break;
		}
}, true);
}
function remplirCust(i){			// 

var customer = document.getElementById('customer'); // On récupère l'élément customer
// Une liste déroulante permettant de choisir le nouveau client dans les formulaires émetteur et destinataire
customer.options[0].text = 'Nouveau Client'; // La valeur de base est nouveau client
customer.options[1].text = myCustomer[0];
customer.options[2].text = myCustomer[5];
customer.options[3].text = myCustomer[10];
customer.options[4].text = myCustomer[15];
customer.options[5].text = mySociety[0];
customer.options[6].text = mySociety[5];
customer.options[7].text = mySociety[10];
customer.options[8].text = mySociety[15];

var nomSoC = document.getElementById('nomSoC');
var nomC = document.getElementById('nomC');
var rueC = document.getElementById('rueC');
var villeC = document.getElementById('villeC');
var telephoneC = document.getElementById('telephoneC');

customer.addEventListener('change', function() {	

	switch(customer.options.selectedIndex){ // Placer automatiquement les attributs du tableau myCustomer en fonction de l'option choisie et de la case destinataire
		case 0 :
			nomSoC.value = "";
			nomSoC.placeholder = 'Nom de la societe';
			nomSoC.disabled = false;
			nomC.value = "";
			nomC.placeholder = 'Nom';
			nomC.disabled = false;
			rueC.value = "";
			rueC.placeholder = 'Rue';
			rueC.disabled = false;
			villeC.value = "";
			villeC.placeholder = 'Code postal, Ville';
			villeC.disabled = false;
			telephoneC.value = "";
			telephoneC.placeholder = 'Numero de telephone';
			telephoneC.disabled = false;
			break;
			
		case 1 :
			nomSoC.value = myCustomer[0];
			nomSoC.disabled = true;
			nomC.value = myCustomer[1];
			nomC.disabled = true;
			rueC.value = myCustomer[2];
			rueC.disabled = true;
			villeC.value = myCustomer[3];
			villeC.disabled = true;
			telephoneC.value = myCustomer[4];
			telephoneC.disabled = true;
			break;
			
		case 2 :
			nomSoC.value = myCustomer[5];
			nomSoC.disabled = true;
			nomC.value = myCustomer[6];
			nomC.disabled = true;
			rueC.value = myCustomer[7];
			rueC.disabled = true;
			villeC.value = myCustomer[8];
			villeC.disabled = true;
			telephoneC.value = myCustomer[9];
			telephoneC.disabled = true;	
			break;
			
		case 3 :
			nomSoC.value = myCustomer[10];
			nomSoC.disabled = true;
			nomC.value = myCustomer[11];
			nomC.disabled = true;
			rueC.value = myCustomer[12];
			rueC.disabled = true;
			villeC.value = myCustomer[13];
			villeC.disabled = true;
			telephoneC.value = myCustomer[14];
			telephoneC.disabled = true;
			break;
		
		case 4 :
			nomSoC.value = myCustomer[15];
			nomSoC.disabled = true;
			nomC.value = myCustomer[16];
			nomC.disabled = true;
			rueC.value = myCustomer[17];
			rueC.disabled = true;
			villeC.value = myCustomer[18];
			villeC.disabled = true;
			telephoneC.value = myCustomer[19];
			telephoneC.disabled = true;	
			break;
		case 5 :
			nomSoC.value = mySociety[0];
			nomSoC.disabled = true;
			nomC.value = mySociety[1];
			nomC.disabled = true;
			rueC.value = mySociety[2];
			rueC.disabled = true;
			villeC.value = mySociety[3];
			villeC.disabled = true;
			telephoneC.value = mySociety[4];
			telephoneC.disabled = true;	
			break;
		case 6 :
			nomSoC.value = mySociety[5];
			nomSoC.disabled = true;
			nomC.value = mySociety[6];
			nomC.disabled = true;
			rueC.value = mySociety[7];
			rueC.disabled = true;
			villeC.value = mySociety[8];
			villeC.disabled = true;
			telephoneC.value = mySociety[9];
			telephoneC.disabled = true;	
			break;
		case 7 :
			nomSoC.value = mySociety[10];
			nomSoC.disabled = true;
			nomC.value = mySociety[11];
			nomC.disabled = true;
			rueC.value = mySociety[12];
			rueC.disabled = true;
			villeC.value = mySociety[13];
			villeC.disabled = true;
			telephoneC.value = mySociety[14];
			telephoneC.disabled = true;	
			break;
		case 8 :
			nomSoC.value = mySociety[15];
			nomSoC.disabled = true;
			nomC.value = mySociety[16];
			nomC.disabled = true;
			rueC.value = mySociety[17];
			rueC.disabled = true;
			villeC.value = mySociety[18];
			villeC.disabled = true;
			telephoneC.value = mySociety[19];
			telephoneC.disabled = true;	
			break;
		}
}, true);
}
var nombre_rangees = 4; // On fixe le nombre de lignes à 4

function  remplir(i){

var list = document.getElementById('list_' + i); // l'element contenu dans list i va dans list

	  
 list.options[1].text = myArray[0]; //l'option dont la valeur est 1 vaut ce qu'il y a dans myArray[0] c'est à dire 'X0154' !-->
 list.options[2].text = myArray[3];
 list.options[3].text = myArray[6];
 list.options[4].text = myArray[9];
 
 var produit = document.getElementById('produit_' +i); // l'element contenu dans 'produit i' va dans produit
 var prixU = document.getElementById('prixUnitaire_' +i); // l'element contenu dans 'prixUnitaire i' va dans prixU
 var myQuantite = document.getElementById('quantite_' + i); // l'element contenu dans 'quantite i' va dans myQuantite
 var afficherMontant = document.getElementById('afficherMontant_'+i); // l'element contenu dans 'afficherMontant i' va dans afficherMontant


 list.addEventListener('change', function() { // lorsque la case est changer on apelle la fonction suivante
	// permet d'etudier différents cas
		switch(list.options.selectedIndex){ //rempli les cases en fonction du choix
			case 0: 
				produit.textContent = " "; 
				prixU.textContent = " ";
				myQuantite.value="0";
				calcule(i);
				break;
			case 1: 
				produit.textContent = myArray[1];
				prixU.textContent = myArray[2];
				calcule(i);
				break;
			case 2: 
				produit.textContent = myArray[4];
				prixU.textContent = myArray[5];
				calcule(i);
				break;
			case 3: 
				produit.textContent = myArray[7];
				prixU.textContent = myArray[8];
				calcule(i);
				break;
			case 4: 
				produit.textContent = myArray[10];
				prixU.textContent = myArray[11];
				calcule(i);
				break;
			}
 
 }, true);
 
 }
 
function calcule(i){

			var prixU = document.getElementById('prixUnitaire_'+i).innerHTML; 
			var myQuantite = document.getElementById('quantite_'+i).value;
			
			var prix = Number(prixU); 
			var quantite = Number(myQuantite);
			somme = prix * quantite;
	
			var afficherMontant = document.getElementById('afficherMontant_'+i);
			afficherMontant.textContent = Math.round(somme*100)/100; // On arrondit le nombre a 2 nombres après la virgule
			total();
			
}

//fonction qui controle le block "veuillez entrer un nombre" verifie chaques rangées avec une boucle
//si la valeur entre n'est pas un nombre valide = false  donc on rentre dans la deuxieme conditions
//donc si valide = true est un nombre alors on laisse le block invisible sinon on l'affiche.
function error(i){
		
		var errorBox = document.getElementById('error');
		var valide = true;
				
		for(j = 0; j < nombre_rangees; j++)
			if(isNaN(Number(document.getElementById('quantite_'+j).value)))
					valide = false;
				
				if(valide)
					{
						errorBox.style.display = 'none';
					}
				 else
					{	
						errorBox.style.display = 'block';
					
					}
}

function total(){ // calcule le total en fonction du produit, prix unitaire, et la quantité
		var Stotal = 0;
		for(var i = 0; i < nombre_rangees ; i++){
			Stotal = Stotal + Number(document.getElementById('afficherMontant_'+i).innerHTML);
		}
		
		var SousTotal = document.getElementById('sous_total');
		SousTotal.textContent = Math.round(Stotal*100)/100 + ' €';
		
		var tva = Stotal*0.20;
		var maTva = document.getElementById('tva');
		maTva.textContent = Math.round(tva*100)/100 + ' €';
		
		var p_m = Stotal*0.10;
		var portEtManutention = document.getElementById('port_manutention');
		portEtManutention.textContent = Math.round(p_m*100)/100 + ' €';
		
		var totalT = Stotal + tva + p_m;
		var total = document.getElementById('total');
		total.textContent = Math.round(totalT*100)/100 + ' €'; 
		
		var remise = 0;
		var remiseBox = document.getElementById('remiseBox');
		remiseBox.className = 'align_center';
		if(totalT > 1000){
			remise = totalT*0.05;
			remiseBox.style.display = 'block';			
			}
		else{
			remiseBox.style.display = 'none';
			}
		var maRemise = document.getElementById('remise');
		maRemise.textContent = Math.round(remise*100)/100;
		
}
 function contact(i){				
	if(i == 0)
	{
		var nomContact = document.getElementById('contactSocNom');
		var nomAcopier = document.getElementById('socNom');
	
		nomContact.value = nomAcopier.value;
	}
	
	else if(i == 1)
	{
		var telContact = document.getElementById('contactNumTel');
		var telAcopier = document.getElementById('numTel');
	
		telContact.value = telAcopier.value;
	}
	
	else if(i == 2)
	{
		var mailContact = document.getElementById('contactAdMail');
		var mailAcopier = document.getElementById('adMail');
	
		mailContact.value = mailAcopier.value;
	}
	
	else 
		alert('Error');

}
function imprimer_page(){ // un bouton qui permet d'imprimer la facture

  window.print();
  
}
 remplir(0);
 remplir(1);
 remplir(2);
 remplir(3);
 remplirSoc(0);
 remplirSoc(1);
 remplirSoc(2);
 remplirSoc(3);
 remplirCust(0);
 remplirCust(1);
 remplirCust(2);
 remplirCust(3);
 remplirCust(4);
 remplirCust(5);
 remplirCust(6);
 remplirCust(7);

 
function scanTouche(evenement){ //  fonction qui intercepte la touche frappéee

		var reCarSpeciaux = /[\x08]/; // variable qui va constituer une sorte d'exception de la touche "delete".
        var reCarValides = /\d/; // variable qui va constituer une sorte d'exception, pour que l'on puisse entrer des valeurs numériques.

        var codeDecimal  = evenement.keyCode; //la variable codeDecimal est créée avec pour valeur le code décimal de la touche qui a été frappée.
        var car = String.fromCharCode(codeDecimal); //convertit la valeur décimale en caractère, exemple: si codeDecimal vaut 97 "car" aura la valeur "a". la comparaison est basée sur le caractère.
        var autorisation = reCarValides.test(car) || reCarSpeciaux.test(car); //on autorise les valeurs numériques OU la touche "delete".

        return autorisation; // on retourne un booleen. autorisation vaut "true" si on a l'autorisation et " false" si on a pas l'autorisation.
		
}

	
function date(){ //Cette fonction ne sert que pour les menus déroulants de la date.
				
				// var pour obtenir le jour, le mois et l'année actuel
				var maintenant = new Date();
				var jour_auj = maintenant.getDate();
				var mois_auj = maintenant.getMonth()+1;
				var annee_auj = maintenant.getFullYear();
				jour = "<OPTION selected>"+jour_auj+"</option>"; // par défaut le jour actuel
				mois = "<option selected>"+mois_auj+"</option>"; // par défaut le mois actuel
				annee = "<option selected>"+annee_auj+"</option>"; // par défaut l'année actuel
				
				var jour ;
				var mois ;
				var annee ;
				var date ;
				for (var j=1; j<=31; ++j){//La boucle pour les jours, de 1 à 31
					 if (j<10){
					 jour += "<OPTION>0"+j+"</OPTION>";// rajoute 0 derrière le le jour pour un jour inférieur à 10 pour avoir 01,02,03 donc 1 chiffre
					 }
					else{
					 jour += "<OPTION>"+j+"</OPTION>"; //  pas besoin de rajouter le 0 car déjà deux chiffres
					 }
				}
				for (var m=1; m<=12; m++){ //Même principe que précédemment, mais de 1 à 12.
					if (m<10){
					 mois += "<OPTION>0"+m+"</OPTION>";
					}
					else{
					 mois += "<OPTION>"+m+"</OPTION>";
					}
				}
				for (var a=1900; a<=2100; a++){ //boucle pour les années jusqu'a 2100.
					annee += "<OPTION>"+a+"</OPTION>";
				}
				
				date = document.getElementById("date");
				date.innerHTML = "<SELECT>"+jour+"</SELECT>" + "<SELECT>"+mois+"</SELECT>" + "<SELECT>"+annee+"</SELECT>";
				
			
			}
date();			
