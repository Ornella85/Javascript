// alert('Hi');


/* var horsTaxe = prompt("Entrez votre montant Hors Taxes : ");

ttc = horsTaxe * 1.2;

document.write('<h2>Le prix ttc de ' + horsTaxe + ' est de : ' + ttc + '€ </h2>');*/

var degres = prompt("Entrez la temperature en degrés c° : ");
fahrenheit = degres * 9/5 + 32;
document.write('<h2>La température saisie en degrés c° est de : ' + degres  + ' équivaut à : ' + fahrenheit + ' f° fahrenheit</h2>');


// Correction 

/* 
var tempC = prompt("Température en degrés celcius à convertir en Farenheit 
tempF = (tempC * 1.8) + 32;
document.write("<h2>" + tempC + "c° = " + tempF + "f°. <h2>); */