// alert("hello");

// L'incrémentation 

var nbr1 = 1;
var nbr1 = nbr1 + 1;

console.log('nbr1 est égale à = ' + nbr1);

// incrémentation avec écriture simplifiée
nbr1++;
console.log('nbr1++; est égale à = ' + nbr1);

// on test à l'inverse
++nbr1; 
console.log('++nbr1; est égale à = ' + nbr1);


// Décrémentation 
nbr1 = nbr1 - 1;
console.log('nbr1 est égale à = ' + nbr1);

//en Écriture simplifiée
nbr1--;
console.log('nbr1--; est égale à = ' + nbr1);

