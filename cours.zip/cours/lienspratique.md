les variables : 
https://www.commentcamarche.net/contents/588-javascript-les-variables

forcer le type d'une variable à changer :
https://stackoverflow.com/questions/48227631/specify-the-variable-type-in-the-prompt


Les mises à jour du langage Javascript :

https://formationjavascript.com/versions-de-javascript-histoire-et-futur/

https://www.wanadev.fr/21-introduction-a-ecmascript-6-le-javascript-de-demain/

es2020 :

https://www.jesuisundev.com/es2020-les-nouveautes-dans-ton-javascript/
